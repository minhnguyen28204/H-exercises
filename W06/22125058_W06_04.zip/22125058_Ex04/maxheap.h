int parent(int* arr, int n, int i);
int Left(int* arr, int n, int i);
int Right(int* arr, int n, int i);
void maxHeapify(int* arr, int n, int i);
void buildMaxHeap(int* arr, int n);
void heapSort(int* arr, int n);
